Node.js RESTful API for student management. Manage database containing students, classes, and the enrollment of students into classes.
